#ifndef	VGATECOMMON_H
#define	VGATECOMMON_H



#endif	// VGATECOMMON_H


